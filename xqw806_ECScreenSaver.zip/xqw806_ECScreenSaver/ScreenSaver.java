import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Scanner;



public class ScreenSaver {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Enter String to use as a ScreenSaver:");
        String str = scnr.nextLine();


        DrawingPanel panel = new DrawingPanel(500, 500);
        Graphics g = panel.getGraphics();

        g.setFont(new Font("Arial", Font.BOLD, 20));
        
        int posX = panel.getWidth() - 1, posY = panel.getHeight() - 1;
        int red = 255, green = 255, blue = 255, iterator = 0;
        while (posX > 0 && posY > 0) {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, panel.getWidth(), panel.getHeight());
            g.setColor(new Color(red, green, blue));
            g.drawString(str+" "+red+" "+green+" "+blue, posX, posY);

            posX--;
            posY--;
            if (iterator == 0) {
                red -= 5;

                if (red < 0) {
                    red = 255;
                    iterator = 1;
                }
            } else if (iterator == 1) {
                green -= 5;
                if (green < 0) {
                    green = 255;
                    iterator = 2;
                }
            }
            else {
                blue -= 5;
                if (blue < 0) {
                    blue = 255;
                    iterator = 0;
                }
            }
            panel.sleep(50);
        }

    }
}
