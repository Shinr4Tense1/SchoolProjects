import java.util.Scanner;

public class RowdyNCalculator{
  
  public static void main(String args[]){
    Scanner scnr = new Scanner(System.in);
  
    System.out.println("UTSA - FALL 2022 - CS1083 - Section 005 - Project I - RowdyNCalculator - written by Jeremy Mutugi");
    System.out.println("Please, input the number of calculations you want to perform: ");
    
    int n = 0; 
    n = scnr.nextInt();
    for (int j = 1; j <= n; j++){
      System.out.println("Operation number " + j);
      System.out.println("Please select your choice of datatypes of operation (i-integer, d-double)");
      String str = scnr.next();
      System.out.println();
      
      if (str.equals("i")){
        System.out.println("Please input the first integer value: ");
        int a = scnr.nextInt();
        System.out.println("Please input the character of the operation (+, -, *, /, %): ");
        String oprtr = scnr.next();
        System.out.println();
        
        System.out.println("Please input the seecond integer value: ");
        int b = scnr.nextInt();
        if (oprtr.equals("+")){
          System.out.println("The result of adding "+ a + " and " + b + " is: " + (a + b));
        }
        else if(oprtr.equals("-")){
          System.out.println("The result of subtracting "+ b + " from " + a + " is: " + (a - b));

        }
        else if(oprtr.equals("*")){
          System.out.println("The result of multiplying "+ a + " by " + b + " is: " + (a * b));
          
        }
        else if(oprtr.equals("/")){
          System.out.println("The result of dividing "+ a + " by " + b + " is: " + (a / b));
          
        }
        else if(oprtr.equals("%")){
          System.out.println("The result of modulo operation"+ a + " by " + b + " is: " + (a % b));
          
        }
        else{
          System.out.println("Wrong operation.");
        }
      }
      else if (str.equals("d")){
        System.out.println("Please input the first double value: ");
        double a = scnr.nextDouble();
        System.out.println("Please input the character of the operation (+, -, *, /, %): ");
        String oprtr = scnr.next();
        System.out.println();
        
        System.out.println("Please input the second double value: ");
        double b = scnr.nextDouble();
        if (oprtr.equals("+")){
          System.out.println("The result of adding "+ a + " and " + b + " is: " + (a + b));
        }
        else if(oprtr.equals("-")){
          System.out.println("The result of subtracting "+ b + " from " + a + " is: " + (a - b));

        }
        else if(oprtr.equals("*")){
          System.out.println("The result of multiplying "+ a + " by " + b + " is: " + (a * b));
          
        }
        else if(oprtr.equals("/")){
          System.out.println("The result of dividing "+ a + " by " + b + " is: " + (a / b));
          
        }
        else if(oprtr.equals("%")){
          System.out.println("The result of modulo operation"+ a + " by " + b + " is: " + (a % b));
          
        }
        else{
          System.out.println("Wrong operation.");
        }
      
      }
      else{
          System.out.println("Wrong datatype.");
        }
      System.out.println("Thank you for using the RowdyNCalculator!");
    }
  

  
  
  
  
  
  
  
  
  }





}