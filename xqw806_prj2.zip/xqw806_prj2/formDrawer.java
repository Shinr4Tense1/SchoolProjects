import java.util.Scanner;

public class formDrawer {

    public static void diamond(Scanner scnr) {
        int size = 0;
        while (true) {
            System.out.println("Enter size: ");
            size = scnr.nextInt();
            if (size <= 0 || size > 80) {
                System.out.println("Invalid size(max->80)");
                continue;
            } else {
                break;
            }
        }
        System.out.println("Enter edge char: ");
        char echar = scnr.next().charAt(0);
        System.out.println("Enter fill char: ");
        char fillchar = scnr.next().charAt(0);
        drawDiamond(size, echar, fillchar);
    }

    public static void showCharNTimes(int n, char c) {
        for (int i = 0; i < n; i++) {
            System.out.print(c);
        }
    }

    public static void drawDiamond(int size, char edgeChar, char fillChar) {
        int j;
        int space = size - 1;
        for (j = 1; j <= size; j++) {
            showCharNTimes(space, ' ');
            space--;
            System.out.print(edgeChar);
            showCharNTimes(2 * j - 3, fillChar);
            if (2 * j - 3 != -1) {
                System.out.print(edgeChar);
            }

            System.out.println("");
        }
        space = 1;
        for (j = 1; j <= size - 1; j++) {
            showCharNTimes(space, ' ');
            space++;
            System.out.print(edgeChar);
            showCharNTimes(2 * (size - j) - 3, fillChar);
            if (2 * (size - j) - 3 != -1) {
                System.out.print(edgeChar);
            }

            System.out.println("");
        }
    }
    public static void rectangle(Scanner scnr) {
        System.out.println("Enter Length: ");
        int length = scnr.nextInt();
        int width = 0;
        while (true) {
            System.out.println("Enter Width: ");
            width = scnr.nextInt();
            if (width <= 0 || width > 80) {
                System.out.println("Invalid Width(max->80)");
                continue;
            } else {
                break;
            }

        }

        System.out.println("Enter fill character: ");
        char c = scnr.next().charAt(0);
        System.out.println("Fill or not fill(y/n): ");
        String f = scnr.next();
        if (f.equals("y")) {
            drawRectangle(length, width, c, false);
        } else {
            drawRectangle(length, width, c, true);
        }

    }

    public static void drawRectangleLine(int size, char fillChar, boolean hollow) {
        if (!hollow) {
            for (int i = 0; i < size; i++) {
                System.out.print(fillChar);
            }
            System.out.println();
        } else {
            for (int i = 0; i < size; i++) {
                if (i == 0 || i == size - 1) {
                    System.out.print(fillChar);
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    public static void drawRectangle(int length, int width, char fillChar, boolean hollow) {
        if (hollow) {
            for (int j = 0; j < length; j++) {
                if (j == 0 || j == length - 1) {
                    drawRectangleLine(width, fillChar, !hollow);
                } else {
                    drawRectangleLine(width, fillChar, hollow);
                }

            }

        } else {
            for (int j = 0; j < length; j++) {
                drawRectangleLine(width, fillChar, hollow);
            }
        }
    }



    public static void triangle(Scanner scnr) {
        int width = 0;
        while (true) {
            System.out.println("Enter Width: ");
            width = scnr.nextInt();
            if (width <= 0 || width > 80) {
                System.out.println("Invalid Width(max->80)");
                continue;
            } else {
                break;
            }

        }
        drawTriangle(width);
    }

    public static void drawTriangle(int width) {
        for (int i = 1; i < width; i++) {
            for (int j = i; j < width; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= (2 * i - 1); j++) {
                if (j == 1) {
                    System.out.print("/");
                }
                if (j == (2 * i) - 1) {
                    System.out.print("\\");
                } else {
                    System.out.print(" ");
                }

            }
            System.out.println("");
        }
        for (int i = 0; i < width * 2; i++) {
            System.out.print("_");
        }
    }



  /*  public static void drawPattern(Scanner scnr) {
        char char1 = scnr.next().charAt(0);
        char char2 = scnr.next().charAt(0);
        boolean ascending = scnr.nextBoolean();
        while (char1 == char2) {
            System.out.print("Please enter different values, char1 and char2 should not be same");
            char1 = scnr.next().charAt(0);
            char2 = scnr.next().charAt(0);
        }

        drawPattern(char1, char2, ascending);

        {
    if (char1 > char2) {
        char temp = char1;
        char1 = char2;
        char2 = temp;
    }
    while (true) {
        System.out.println("Ascending triangle?(y/n):");
        String asc = scnr.next();
        if (asc.equals("y") || asc.equals("n")) {
            break;
        } else {
            System.out.println("Invalid Input. Enter either y or n: ");
            continue;
        }
    }
    String asc = scnr.next();
    if (asc.equals("y")) {
        drawPattern(char1, char2, true);
    } else {
        drawPattern(char1, char2, false);
    }
   }


}

public static void drawPattern(char char1, char char2, boolean ascending) {

    if (char1 > char2) {
        char temp = char1;
        char1 = char2;
        char2 = temp;
    }

    if (ascending) {

        while (char1 <= char2) {

            for (char ch = char1; ch <= char2; ch++) {
                System.out.print(ch + " ");
            }

            System.out.println();

            char1++;
        }
    } else {

        while (char1 <= char2) {

            for (char ch = char2; ch >= char1; ch--) {
                System.out.print(ch + " ");
            }
            System.out.println();

            char2--;
        }
    }
}
*/
public static void showMenu() {
    System.out.println("Fall 2022 - CS1083 - Section 005 - Project 2 - FormDrawer - written by Jeremy Mutugi");
    System.out.println("Please, select one of the following options");
    System.out.println("0.Exit");
    System.out.println("1.Print a Diamond");
    System.out.println("2.Print a Rectangle");
    System.out.println("3.Print a Triangle");
    // System.out.println("4.Print a Pattern");
}
public static void getMenuSelection() {
    Scanner scnr = new Scanner(System.in);
    while (true) {
        showMenu();
        int choice = scnr.nextInt();

        if (choice == 0) {
            System.out.println("Thank you for using the formDrawer program, Good bye!");
            break;
        }
        if (choice == 1) {
            diamond(scnr);
            continue;
        }
        if (choice == 2) {
            rectangle(scnr);
            System.out.println();
            continue;
        }
        if (choice == 3) {
            triangle(scnr);
            continue;
        }
        /*if (choice == 4) {
            drawPattern(scnr);
            continue;
        }*/
        else {
            System.out.println("Incorrect option, please, try again.");
            continue;
        }

    }
}

public static void main(String[] args) {
    getMenuSelection();
}
}