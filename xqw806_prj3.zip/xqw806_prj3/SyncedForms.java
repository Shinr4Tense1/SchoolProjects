import java.awt.*;
import java.util.*;


public class SyncedForms {
    public static void main(String[] args) {
        System.out.println("UTSA – Fall 2022 - CS1083 - Section 005 - Project 3 - SyncedForms - written by Jeremy Mutugi");

        // Start the rest of the program by calling the drawSyncedForms method
        drawSyncedForms();


    }

    public static void drawSyncedForms() {
        // Create a drawing panel of size 400x400 pixels
        DrawingPanel panel = new DrawingPanel(400, 400);
        panel.setBackground(Color.WHITE);

        // Create a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user to select the shape of the forms to display
        System.out.println("Enter the shape of the forms (C for circles, S for squares):");
        char shape = scanner.nextLine().charAt(0);

        // Ask the user for the number of forms to display
        System.out.println("Enter the number of forms to display (up to 9):");
        int numForms = scanner.nextInt();

        // Create arrays to store the x and y positions of the forms
        int[] xPositions = new int[numForms];
        int[] yPositions = new int[numForms];


        // Call the initialPosition method to initialize the positions of the forms
        initialPosition(xPositions, yPositions, numForms);


        // Create an array to store the colors of the forms
        Color[] colors = new Color[numForms];

        // Call the initialColor method to assign colors to the forms
        initialColor(colors, numForms);

        // Ask the user for the number of movements to show
        System.out.println("Enter the number of movements to show:");
        int numMoves = scanner.nextInt();


        // Call the moveForms method to move the forms on the drawing panel
        moveForms(panel, shape, xPositions, yPositions, colors, numForms, numMoves);
    }

    public static void initialPosition(int[] xPositions, int[] yPositions, int numForms) {
        int panelWidth = 400;
        int panelHeight = 400;
        int formSize = 50;

        // Calculate the horizontal and vertical spacing between forms
        int horizontalSpacing = (panelWidth - (formSize * numForms)) / (numForms + 1);
        int verticalSpacing = (panelHeight - (formSize * numForms)) / (numForms + 1);

        for (int i = 0; i < numForms; i++) {
            // Calculate the x and y position of the form
            int x = horizontalSpacing + (i * (formSize + horizontalSpacing));
            int y = verticalSpacing + (i * (formSize + verticalSpacing));

            // Store the position in the xPositions and yPositions arrays
            xPositions[i] = x;
            yPositions[i] = y;
        }
    }

    public static void initialColor(Color[] colors, int numForms) {
        // Assign the colors to the forms
        for (int i = 0; i < numForms; i++) {
            if (i == 0) {
                colors[i] = Color.GREEN;
            } else if (i == 1) {
                colors[i] = Color.GRAY;
            } else if (i == 2) {
                colors[i] = Color.YELLOW;
            } else if (i == 3) {
                colors[i] = Color.RED;
            } else if (i == 4) {
                colors[i] = Color.ORANGE;
            } else if (i == 5) {
                colors[i] = Color.PINK;
            } else if (i == 6) {
                colors[i] = Color.DARK_GRAY;
            } else if (i == 7) {
                colors[i] = Color.BLUE;
            } else if (i == 8) {
                colors[i] = Color.BLACK;
            }
        }
    }

    public static void moveForms(DrawingPanel panel, char shape, int[] xPositions, int[] yPositions, Color[] colors, int numForms, int numMoves) {
        // Create a Graphics object for drawing on the panel
        Graphics g = panel.getGraphics();
        Scanner scnr = new Scanner(System.in);


        for (int i = 0; i < numMoves; i++) {
            // Prompt the user for the next move
            System.out.println("Enter the number of moves:");
            int move = scnr.nextInt();

            // Update the position of each form according to the user's move
            for (int j = 0; j < numForms; j++) {
                moveForm(xPositions, yPositions, j, move);
                showForms(panel, shape, xPositions[j], yPositions[j], colors[j], 50);
            }
        }

        // Clear the panel
        g.clearRect(0, 0, panel.getWidth(), panel.getHeight());

        // Draw the forms at their new positions
        for (int j = 0; j < numForms; j++) {
            g.setColor(colors[j]);
            if (shape == 'S') {
                // Draw a rectangle
                g.fillRect(xPositions[j], yPositions[j], 50, 50);
            } else if (shape == 'C') {
                // Draw a circle
                g.fillOval(xPositions[j], yPositions[j], 50, 50);
            }
        }

        // Update the panel
        panel.sleep(50);
    }

    public static void moveForm(int[] xPositions, int[] yPositions, int form, int orientation) {
        // Calculate the x and y offsets for the given orientation
        int xOffset = 0;
        int yOffset = 0;
        if (orientation == 1) {
            xOffset = -25;
            yOffset = -25;
        } else if (orientation == 2) {
            yOffset = -25;
        } else if (orientation == 3) {
            xOffset = 25;
            yOffset = -25;
        } else if (orientation == 4) {
            xOffset = -25;
        } else if (orientation == 6) {
            xOffset = 25;
        } else if (orientation == 7) {
            xOffset = -25;
            yOffset = 25;
        } else if (orientation == 8) {
            yOffset = 25;
        } else if (orientation == 9) {
            xOffset = 25;
            yOffset = 25;
        }

        // Update the x and y positions of the form
        xPositions[form] += xOffset;
        yPositions[form] += yOffset;
    }

    public static void showForms(DrawingPanel panel, char shape, int x, int y, Color color, int size) {
        Graphics g = panel.getGraphics();

        g.setColor(color);
        if (shape == 'C') {
            // Draw a filled circle at the given position with the given color
            g.fillOval(x, y, size, size);
        } else if (shape == 'S') {
            // Draw a filled square at the given position with the given color
            g.fillRect(x, y, size, size);
        }

        // Set the outline color to black and draw the outline of the form
        g.setColor(Color.BLACK);
        if (shape == 'C') {
            // Draw the outline of the circle at the given position
            g.drawOval(x, y, size, size);
        } else if (shape == 'S') {
            // Draw the outline of the square at the given position
            g.drawRect(x, y, size, size);
        }
    }
}





